import sys
lines = sys.stdin.readlines()
order = "`1234567890-=QWERTYUIOP[]\\ASDFGHJKL;\'ZXCVBNM,./"
for line in lines:
  for i in range(len(line)-1):
    if(line[i] == " "):
      print(end=" ")
    else:
      print(order[order.find(line[i])-1],end="")
  print("")
