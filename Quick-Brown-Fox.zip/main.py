import sys

pInput = sys.stdin.readlines()
for i in range(1, len(pInput)):
    reqs = dict.fromkeys(
        'a b c d e f g h i j k l m n o p q r s t u v w x y z'.split(), 0)
    for c in (pInput[i].lower()):
        reqs.pop(c, None)
    if len(reqs) == 0:
        print("Pangram")
    else:
        printedString = ""
        for c in reqs:
            printedString += c
        print("missing", printedString)
