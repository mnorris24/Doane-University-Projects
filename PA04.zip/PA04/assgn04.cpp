#include <cstdlib>
#include <iostream>
#include <set>
#include <string>
#include "Stack.h"

/**
 * Main program for the Doane RPN calculator.
 */
int main() {
  using namespace std;
  int a = 0;
  int b = 0;
  int end = 0;
  string stop = "EOF";
  string E = "E";
  string add = "+";
  string subtract = "-";
  string multiply = "*";
  string devide = "/";
    using namespace std;
    
    // welcome prompt
    cout << "Welcome to the Doane RPN Calculator!" << endl;
    cout << "Please enter an expression in postfix, EOF to quit." << endl;
    
    // prepare stack
    Stack<double> stack;

    // read string tokens until there is nothing more to read    
    string token;
    while(cin >> token) {
      if(token == E){
        cout << stack.pop() << endl;
        stack.clear();
       }
      else if(token == add || token == subtract || token == multiply || token == devide){
        b = stack.pop();
        a = stack.pop();
        if(token == add){
          end = a + b;
          stack.push(end);
        }else if(token == subtract){
          end = a - b;
          stack.push(end);  
        }else if(token == multiply){
          end = a * b;
          stack.push(end); 
        }else if(token == devide){
          end = a / b;
          stack.push(end); 
        }
        }else if(token == stop){
            cout << "Good bye!" << endl;
    
    return EXIT_SUCCESS;
    
  }
        
        else{
          double num = stod(token);
          stack.push(num);
        }
    
      
        // TODO: based on token type (operator, "E", or number),
        // use the stack to implement the operations of the
        // RPN calculator. 
    
    
    // good by prompt
    }
}