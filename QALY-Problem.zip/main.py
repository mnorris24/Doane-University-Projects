result = 0.0
pCount = int(input())
for i in range(pCount):
  period = input()
  spaceLoc = period.index(' ')
  qol = float(period[0:spaceLoc])
  yrs = (float(period[spaceLoc+1:len(period)]))
  result += qol * yrs
print (result)
