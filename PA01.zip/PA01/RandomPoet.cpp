#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>
#include "SimpleSLL.h"

int main() {
  srand(time(0));
    using namespace std;
    
    // welcome message
    cout << "Welcome to the random poetry generator!\n" <<
        "Please wait while the dictiionary is loaded." << endl;
    
    // load dictionary
    SimpleSLL dictionary;
    ifstream inFile("dictionary.txt");
    string w;
    while(inFile >> w) {
        dictionary.add(w);
    }
    inFile.close();
    
    // lines, words, prompt variables
    unsigned lines = 0, words = 0, prompt = 0;
    
    // poetry loop
    do {
        cout << "Let's make some poetry, dude! Enter the number of lines: ";
        cin >> lines;
        
        cout << "Radical! Now, enter the number of words per line: ";
        cin >> words;
        
        cout << "\nHere's your poem, man!";
        
        for(unsigned i = 0u; i < lines; i++) {
            cout << "\t";
            for(unsigned j = 0u; j < words; j++) {
                cout << dictionary.getRandom() << " ";
            }
            cout << endl;
        }
        
        cout << "\nWould you like to make another poem? " << 
            "Enter 1 for yes, 0 for no: ";
        cin >> prompt;
        
    } while(prompt == 1);
    
    return EXIT_SUCCESS;
}